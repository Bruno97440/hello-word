<?php

namespace Unflr\Exceptions;

class AlreadyRegistered extends \ExpectedException {}
class RegistrationFailed extends \ExpectedException {}
