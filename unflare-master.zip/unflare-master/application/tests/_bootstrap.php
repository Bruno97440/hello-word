<?php
// Here you can initialize variables that will for your tests

\Codeception\Util\Autoload::registerSuffix('Group', __DIR__.DIRECTORY_SEPARATOR.'_groups');
date_default_timezone_set('Europe/Paris');