<?php

return [

	'mandrill' => [
		'secret' => MANDRILL_KEY,
	],

];
