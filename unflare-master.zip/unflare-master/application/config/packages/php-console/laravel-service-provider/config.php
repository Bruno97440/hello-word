<?php

// See options description in corresponding PhpConsole\Laravel\ServiceProvider properties annotations

return array(
	'isEnabled' => DEBUG,
);
