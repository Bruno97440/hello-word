<?php

return array(
    'enabled' => true,
    'format' => '.%s.',
    'extensions' => array(
        'js', 'css'
    )
);
