<?php

return [

	// View Storage Paths
	'paths' => [__DIR__.'/../views'],

	// Pagination View (Bootstrap by default)
	'pagination' => 'pagination::slider',

];
