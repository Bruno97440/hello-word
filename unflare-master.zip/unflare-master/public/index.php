<?php

// yeb paths, globals and composer
require __DIR__.'/../application/bootstrap.php';
