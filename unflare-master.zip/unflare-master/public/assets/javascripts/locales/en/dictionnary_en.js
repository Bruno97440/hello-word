$.i18n.setDictionary({ 

});